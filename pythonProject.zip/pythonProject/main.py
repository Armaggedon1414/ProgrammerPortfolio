import pygame as pg
import random as ran
from os import path
from time import sleep as slp

# Game Object Classes
class Player(pg.sprite.Sprite):
    def __init__(self):
        super(Player, self).__init__()
        self.shield = 100
        self.image = playerImg
        self.image = pg.transform.scale(playerImg, (70, 70))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.radius = int(self.rect.width * .5/2)
        self.rect.centerx = (WIDTH / 2)
        self.rect.centery = (HEIGHT * (9 / 10))
        self.speedx = 0
        self.cooldown = 300
        self.last = 0
        self.playerx, self.playery = self.rect.center

    def update(self):
        global health
        global invincible
        self.now = pg.time.get_ticks()

        if self.rect.right >= WIDTH:
            self.rect.right = WIDTH
        if self.rect.left <= 0:
            self.rect.left = 0
        keystateD = pg.key.get_pressed()
        self.speedx = 0
        if keystateD[pg.K_LEFT] or keystateD[pg.K_a]:
            self.speedx = -5
        if keystateD[pg.K_RIGHT] or keystateD[pg.K_d]:
            self.speedx = 5
        if keystateD[pg.K_UP] or keystateD[pg.K_SPACE] or keystateD[pg.K_w]:
            if self.now - self.last >= self.cooldown:
                shoot(self.rect.centerx, self.rect.top)
                self.last = pg.time.get_ticks()
        self.rect.x += self.speedx
        for i in range(health):
            showHearts(((WIDTH / 30) + 30 * i), (HEIGHT / 45))

class NPC(pg.sprite.Sprite):
    def __init__(self):
        super(NPC, self).__init__()
        self.width = ran.randint(60, 150)
        self.image = asteroidImg
        self.image_orig = pg.transform.scale(self.image, (self.width, self.width))
        self.image_orig.set_colorkey(BLACK)
        self.image = self.image_orig.copy()
        self.newImg = self.image
        self.rect = self.image.get_rect()
        self.radius = self.width/4
        self.rect.centerx = (WIDTH / 2)
        self.rect.centery = (-50)
        self.speedy = ran.randint(3, 6)
        self.speedx = ran.randint(-3, 3)
        self.rot = 0
        self.rotSpeed = ran.randint(-8, 8)
        self.lastUpdate = pg.time.get_ticks()

    def update(self):
        if self.rect.top >= HEIGHT:
            self.rect.bottom = 0
            self.rect.centerx = (ran.randint(20, (WIDTH - 20)))
        if self.rect.right > WIDTH or self.rect.left < 0:
            self.speedx *= -1
        self.rect.y += self.speedy
        self.rect.x += self.speedx

    def rotate(self):
        now = pg.time.get_ticks()
        if now - self.lastUpdate > 60:
            self.lastUpdate = now
            # Do the Rotation
            self.rot = (self.rot+self.rotSpeed)%360
            newImg = pg.transform.rotate(self.image_orig, self.rot)
            oldCenter = self.rect.center
            self.image = newImg
            self.rect = self.image.get_rect()
            self.rect.center = oldCenter

    def spawn(self):
        npc = NPC()
        mobsGroup.add(npc)
        allSprites.add(npc)

class Bullet(pg.sprite.Sprite):
    def __init__(self):
        super(Bullet, self).__init__()
        self.image = laserImg
        self.image = pg.transform.scale(self.image, (40, 40))
        self.rect = self.image.get_rect()
        self.radius = 5
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.speedy = -15

    def update(self):
        if self.rect.bottom <= 0:
            self.kill()
        self.rect.y += self.speedy


def shoot(x, y):
    bullet = Bullet()
    bullet.rect.center = (x, y)
    allSprites.add(bullet)
    bulletsGroup.add(bullet)
    shootSnd.play()


class Heart(pg.sprite.Sprite):
    def __init__(self):
        super(Heart, self).__init__()
        self.image = heartImg
        self.image = pg.transform.scale(self.image, (60, 60))
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()

    def update(self):
        global health
        self.kill()

# Game Functions
def showHearts(x, y):
    heart = Heart()
    heart.rect.center = (x, y)
    hudGroup.add(heart)
    allSprites.add(heart)

def gameOver():
    quit()

def drawText(surf, text, size, x, y, color):
    font = pg.font.SysFont(FONTNAME, size)
    textSurf = font.render(text, True, color)
    textRect = textSurf.get_rect()
    textRect.midtop = (x, y)
    surf.blit(textSurf, textRect)

def drawBar(surf, x, y, pct):
    if pct < 0:
        pct = 0
    barLen = 150
    barHeight = 20
    fill = (pct/100)*barLen
    outlineRect = pg.Rect(x, y, barLen, barHeight)
    fillRect = pg.Rect(x, y, fill, barHeight)
    pg.draw.rect(surf, GREEN, fillRect)
    pg.draw.rect(surf, WHITE, outlineRect, 2)

# Game Constants
FONTNAME = "Arial"
HEIGHT = 900
WIDTH = 600
FPS = 60
STARTHEALTH = 5
health = STARTHEALTH
title = "Space Shooter"
invincible = False
gameFolder = path.dirname(__file__)
imgDir = path.join(gameFolder, "imgs")
sndDir = path.join(gameFolder, "snds")
score = 0

# Colors List
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
ORANGE = (255, 165, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
PURPLE = (149, 0, 149)
PINK = (255, 0, 255)
BROWN = (165, 42, 42)
CORNFLOWER = (100, 149, 237)
COLORLIST = [BLACK, WHITE, RED, ORANGE, GREEN, BLUE, PURPLE, PINK, BROWN, CORNFLOWER]

# Initialize Pygame
pg.init()
pg.mixer.init()

screen = pg.display.set_mode((WIDTH, HEIGHT))
pg.display.set_caption(title)
clock = pg.time.Clock()

# Sprite Groups
allSprites = pg.sprite.Group()
playersGroup = pg.sprite.Group()
mobsGroup = pg.sprite.Group()
bulletsGroup = pg.sprite.Group()
hudGroup = pg.sprite.Group()

# Load IMGS
background = pg.image.load(path.join(imgDir, "Space.png"))
background = pg.transform.scale(background, (WIDTH, HEIGHT))
backgroundRect = background.get_rect()
playerImg = pg.image.load(path.join(imgDir, "PlayerImg.png")).convert()
asteroidImg = pg.image.load(path.join(imgDir, "Asteroid.png")).convert()
laserImg = pg.image.load(path.join(imgDir, "Laser.png")).convert()
heartImg = pg.image.load(path.join(imgDir, "heart.png")).convert()

# Load SNDS
shootSnd = pg.mixer.Sound(path.join(sndDir, "pew.wav"))
explSnds = []
for snd in ["expl3.wav", "expl6.wav"]:
    explSnds.append(pg.mixer.Sound(path.join(sndDir, snd)))
pg.mixer.music.load(path.join(sndDir, "backgroundMusic.ogg"))
pg.mixer.music.set_volume(0.4)
pg.mixer.music.play(loops=-1)

# Create game Objects
player = Player()
for i in range(10):
    npc = NPC()
    mobsGroup.add(npc)

# Add objects to Sprite Groups
playersGroup.add(player)

for i in playersGroup:
    allSprites.add(i)
for i in mobsGroup:
    allSprites.add(i)

# Game Loop
playing = True
while playing:
    # Run Speed
    clock.tick(FPS)

    # Quitting the Game
    for event in pg.event.get():
        if event.type == pg.KEYDOWN:
            if event.type == pg.K_ESCAPE:
                playing = False
        if event.type == pg.QUIT:
            playing = False

    if health == 0:
        playing = False

    Playerhits = pg.sprite.spritecollide(player, mobsGroup, True, pg.sprite.collide_circle)
    if Playerhits:
        npc.spawn()
        ran.choice(explSnds).play()
        player.shield -= npc.radius/2
        if player.shield <= 0:
            health -= 1
            slp(3)
            player.shield = 100

    Bullethits = pg.sprite.groupcollide(bulletsGroup, mobsGroup, True, True, pg.sprite.collide_circle)
    for hit in Bullethits:
        score += (160 - npc.radius)
        npc.spawn()


    # Update Everything
    allSprites.update()





    # Render all Changes
    screen.fill(BLACK)
    screen.blit(background, backgroundRect)

    allSprites.draw(screen)

    # Draw Hud
    drawText(screen, "Score: "+str(score), 20, WIDTH/2, 10, WHITE)
    drawBar(screen, 5, 50, player.shield)

    pg.display.flip()

pg.quit()